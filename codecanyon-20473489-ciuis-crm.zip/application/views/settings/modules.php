<md-content class="md-padding" layout-xs="column" layout="row">
    <br><br>
    <p class="text-center not-found" style="width: 100%;">Coming Soon!</p>
<!--     <div flex-xs flex-gt-xs="20" layout="column">
        <md-card>
            <img ng-src="<?php echo base_url('assets/img/payment-modes/mercado.png')?>" class="md-card-image md-padding" alt="mercado">
            <md-card-title>
                <md-card-title-text>
                    <h3>Mollie</h3>
                </md-card-title-text>
            </md-card-title>
            <md-card-actions layout="row" layout-align="start center">
                <md-card-icon-actions>
                    <md-button class="md-raised md-primary primary-button">Buy</md-button>
                </md-card-icon-actions>
                <md-button class="md-raised md-primary primary-button">Activate</md-button>
            </md-card-actions>
            <md-card-content style="padding: unset;">
                <div class="panel">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-controls="collapseOne">
                                Mollie Payment Gateway  &nbsp;&nbsp;&nbsp;&nbsp;
                                <md-icon>
                                    <i class="ion-chevron-down"></i>
                                </md-icon>
                            </a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            Transformá tu manera de pagar, cobrá como quieras y no pares de vender. Accedé a un préstamo para hacer crecer tu proyecto.
                        </div>
                    </div>
                </div>
            </md-card-content>
        </md-card>
    </div> -->
</md-content>