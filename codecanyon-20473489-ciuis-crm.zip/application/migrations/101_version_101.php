<?php
defined( 'BASEPATH' )OR exit( 'No direct script access allowed' );

class Migration_Ciuis_101 extends CI_Migration {
	function __construct() {
		parent::__construct();
	}

	public

	function up() {

		

	}

}