<div class="main_wrapper">
    <div class="row">
        <div class="col-sm-12">
            <div class="alert alert-success">
            <h3 id="completeMessage"></h3> 
            </div> 
            <div class="divider"></div>
            <div class="col-md-12 md-p-0">
              <div class="panel panel-default">
                <div class="panel-heading panel-heading-divider xs-pb-15">Login Informations</div>
                <div class="panel-body xs-pt-25">
                  <div class="row user-progress user-progress-small">
                    <div class="col-md-5"><span class="title">E-Mail</span></div>
                    <div class="col-md-7">
                       <b>root@ciuis.com</b>
                    </div>
                  </div>
                  <div class="row user-progress user-progress-small">
                    <div class="col-md-5"><span class="title">Password</span></div>
                    <div class="col-md-7">
                       <b>root</b>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="browse" class="hidden text-center">
                <a href="../index.php" class="btn btn-default ">Login</a>
            </div> 
        </div>
    </div>
</div>